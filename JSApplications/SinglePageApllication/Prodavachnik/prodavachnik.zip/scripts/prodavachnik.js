function startApp() {
    showHideMenuLinks();
    showView('viewHome');
    attachAllEvents()
}